
var secrets = {
    mongolab: {
        username: "colt",
        password: "rusty"
    }
};

module.exports = secrets;
